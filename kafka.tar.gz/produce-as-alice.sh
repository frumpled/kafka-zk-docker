#!/bin/bash

KAFKA_LOG4J_OPTS="-Dlog4j.configuration=file:/usr/bin/kafka/config/log4j.properties"

bin/kafka-console-producer-alice.sh --broker-list localhost:9092 --topic test --producer.config config/producer.properties
