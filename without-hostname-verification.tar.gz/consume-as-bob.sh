bin/kafka-console-consumer-bob.sh --bootstrap-server localhost:9092 --topic ${1:-test} --consumer.config config/consumer.properties --from-beginning
