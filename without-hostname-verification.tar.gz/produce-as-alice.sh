#!/bin/bash

#bin/kafka-console-producer-alice.sh --broker-list 10.185.48.66:9092,10.185.57.68:9092,10.185.52.229:9092 --topic ${1:-test} --producer.config config/producer.properties
bin/kafka-console-producer-alice.sh --broker-list kafka-sasl-ssl-test.internal:9092 --topic ${1:-test} --producer.config config/producer.properties
#bin/kafka-console-producer-alice.sh --broker-list localhost:9092,10.185.57.68:9092 --topic ${1:-test} --producer.config config/producer.properties
