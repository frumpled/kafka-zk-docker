#!/bin/bash

bin/kafka-console-consumer-bob.sh --bootstrap-server localhost:9092 --topic test --consumer.config config/consumer.properties --from-beginning
