/zookeeper-3.4.13/bin/zkServer.sh stop
